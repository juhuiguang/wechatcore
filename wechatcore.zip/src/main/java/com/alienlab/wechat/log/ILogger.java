package com.alienlab.wechat.log;

public interface ILogger {
	/**
	 * 记录日志
	 */
	public void doLog();
}
