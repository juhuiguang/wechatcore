package com.alienlab.wechat.message.inter;

public interface IMediaFile {

}
